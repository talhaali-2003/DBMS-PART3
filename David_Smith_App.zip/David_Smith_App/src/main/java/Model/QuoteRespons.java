package Model;

public class QuoteRespons {
    private int id;
    private int clientId;
    private int quoteId;
    private String responseDetails;

    // Constructors, getters, setters
}

